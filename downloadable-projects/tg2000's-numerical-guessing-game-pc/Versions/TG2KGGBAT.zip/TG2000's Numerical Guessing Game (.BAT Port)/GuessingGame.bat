@echo off

::TG2000's Numerical Guessing Game (.BAT Port)
::By TheGamer2000 - Build Date: 9/6/2026 - Build #030 - Final? YES

::STARTING SEQUENCE (LOGO), ONLY DISPLAY THIS ONCE

:START SEQUENCE
cls
timeout /t 1 /nobreak >nul
ECHO.
ECHO - A Game by TheGamer2000 -
timeout /t 3 /nobreak >nul
GOTO TITLE

::MAIN MENU

:TITLE
cls
set /a guessnum=1
set /a guessnum=%guessnum% +1
set /a banswer=%random% %%50
set /a eanswer=%random% %%100
set /a hanswer=%random% %%300
set /a danswer=%random% %%500
set /a battempts=21
set /a eattempts=11
set /a hattempts=11
set /a dattempts=6
timeout /t 1 /nobreak >nul
ECHO.
ECHO TG2000 Presents:
ECHO TG2000's Numerical Guessing Game
ECHO.
ECHO Programmed and Ported by TG2000 - (C)2023, 2026
ECHO.
ECHO Options:
ECHO 1 - Start Game
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "Start the Game"
IF %ERRORLEVEL% EQU 1 GOTO DIFFICULTY
IF %ERRORLEVEL% EQU 2 GOTO QUIT

:DIFFICULTY
timeout /t 1 /nobreak >nul
ECHO.
ECHO Select a Difficulty!
ECHO 1 - Baby Mode
ECHO 2 - Easy Mode
ECHO 3 - Hard Mode
ECHO 4 - Devilish Mode
ECHO.
CHOICE /C 1234 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO BABY
IF %ERRORLEVEL% EQU 2 GOTO EASY
IF %ERRORLEVEL% EQU 3 GOTO HARD
IF %ERRORLEVEL% EQU 4 GOTO HELL

::BABY MODE

:BABY
cls
set /a battempts-=1
set /a bmaxattempts=1
ECHO.
ECHO Pick a number from 1 to 50!
ECHO.
ECHO Guesses Remaining: %battempts%
ECHO.
set /p bguess= Enter: 
if %battempts%==%bmaxattempts% goto BFAIL
if %bguess% GTR %banswer% goto BHIGH
if %bguess% LSS %banswer% goto BLOW
if %bguess%==%banswer% goto BCORRECT

:BUNK
ECHO.
ECHO Please enter a number! Try again!
ECHO.
timeout /t 2 /nobreak >nul
IF %ERRORLEVEL% EQU 1 GOTO BABY


:BHIGH
cls 
ECHO.
ECHO Guess a bit lower! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO BABY

:BLOW
cls 
ECHO.
ECHO Guess a bit higher! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO BABY

:BCORRECT
cls
ECHO.
ECHO You figured it out! Congratulations!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT

:BFAIL
cls
ECHO.
ECHO You've run out of guesses! Game Over!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT

::EASY MODE

:EASY
cls
set /a eattempts-=1
set /a emaxattempts=1
ECHO.
ECHO Pick a number from 1 to 100!
ECHO.
ECHO Guesses Remaining: %eattempts%
ECHO.
set /p eguess= Enter: 
if %eattempts%==%emaxattempts% goto EFAIL
if %eguess% GTR %eanswer% goto EHIGH
if %eguess% LSS %eanswer% goto ELOW
if %eguess%==%eanswer% goto ECORRECT

:EHIGH
cls 
ECHO.
ECHO Guess a bit lower! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO EASY

:ELOW
cls 
ECHO.
ECHO Guess a bit higher! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO EASY

:ECORRECT
cls
ECHO.
ECHO You figured it out! Congratulations!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT

:EFAIL
cls
ECHO.
ECHO You've run out of guesses! Game Over!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT

::HARD MODE

:HARD
cls
set /a hattempts-=1
set /a hmaxattempts=1
ECHO.
ECHO Pick a number from 1 to 300!
ECHO.
ECHO Guesses Remaining: %hattempts%
ECHO.
set /p hguess= Enter: 
if %hattempts%==%hmaxattempts% goto HFAIL
if %hguess% GTR %hanswer% goto HHIGH
if %hguess% LSS %hanswer% goto HLOW
if %hguess%==%hanswer% goto HCORRECT

:HHIGH
cls 
ECHO.
ECHO Guess a bit lower! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO HARD

:HLOW
cls 
ECHO.
ECHO Guess a bit higher! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO HARD

:HCORRECT
cls
ECHO.
ECHO You figured it out! Congratulations!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT

:HFAIL
cls
ECHO.
ECHO You've run out of guesses! Game Over!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT

::DEVILISH MODE

:HELL
cls
set /a dattempts-=1
set /a dmaxattempts=1
ECHO.
ECHO Pick a number from 1 to 500!
ECHO.
ECHO Guesses Remaining: %dattempts%
ECHO.
set /p dguess= Enter: 
if %dattempts%==%dmaxattempts% goto DFAIL
if %dguess% GTR %danswer% goto DHIGH
if %dguess% LSS %danswer% goto DLOW
if %dguess%==%danswer% goto DCORRECT

:DHIGH
cls 
ECHO.
ECHO Guess a bit lower! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO HELL

:DLOW
cls 
ECHO.
ECHO Guess a bit higher! Try again!
ECHO.
timeout /t 2 /nobreak >nul
GOTO HELL

:DCORRECT
cls
ECHO.
ECHO You figured it out! Congratulations!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT

:DFAIL
cls
ECHO.
ECHO You've run out of guesses! Game Over!
ECHO.
timeout /t 1 /nobreak >nul
ECHO Play Again?
ECHO 1 - Yes
ECHO 2 - No
ECHO.
CHOICE /C 12 /M "Enter an Option"
IF %ERRORLEVEL% EQU 1 GOTO TITLE
IF %ERRORLEVEL% EQU 2 GOTO QUIT
:QUIT
cls
PAUSE

::END OF PROGRAM