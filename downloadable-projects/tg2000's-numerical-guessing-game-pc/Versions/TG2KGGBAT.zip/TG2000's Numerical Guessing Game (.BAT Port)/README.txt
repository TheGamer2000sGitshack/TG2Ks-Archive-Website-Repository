TG2000's Numerical Guessing Game (.BAT Port)

Original game by TheGamer2000, ©2023

Ported to .BAT, ©2026  

--------
RUN-DOWN
--------
A simple game where you guess the number! 

Play in 4 difficulty modes and see what you can do!

----------------------
START GUIDE & CONTROLS
----------------------
Simply click on the GuessingGame.bat file to begin playing!

(If on Windows CMD, type in GuessingGame.bat while in this folder and hit the Enter key.)

Use the enter key to start the game and to imput your guess.

Use the number keys to select an option when prompted and when entering a number.

If any errors are to occur at any time, use the CTRL+C command to quit the program.

-----
NOTES
-----
This version of "TG2000's Numerical Guessing Game" is only designed for use on machines running Windows Vista through 11.

Based on the Flowlab port of the game.

Have fun playing!