@echo off

::Thirsty for Milk
::A Game of Self-Choice - By TheGamer2000 - Build Date: 7/14/2026 - Build #022 - Final? YES
::Based on a story I wrote 3 years ago for a cancelled interactive game

::STARTING SEQUENCE (LOGO), ONLY DISPLAY THIS ONCE
::ASCII GRAPHICS ARE STORED IN THE ASCII FOLDER

:START SEQUENCE
cls
timeout /t 2 /nobreak >nul
ECHO.
cd "ASCII"
type TG2000.txt
cd ..
timeout /t 5 /nobreak >nul
GOTO TITLE

::TITLE SCREEN

:TITLE
cls
timeout /t 1 /nobreak >nul
ECHO.
cd "ASCII"
type LOGO.txt
cd ..
ECHO.
ECHO Written + Programmed By TG2000, (C)2026
ECHO.
ECHO Options
ECHO 1 - Start Game
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "Start the Game"
IF %ERRORLEVEL% EQU 1 GOTO START
IF %ERRORLEVEL% EQU 2 GOTO QUIT

::START OF THE GAME

:START
cls
timeout /t 1 /nobreak >nul
ECHO.
ECHO It's a fine afternoon, and you're just relaxing in your home. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO START2

:START2
cls
ECHO.
ECHO All of a sudden, you find yourself feeling quite thirsty.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO START3

:START3
cls
ECHO.
ECHO Water doesn't cut it for you. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO START4

:START4
cls
ECHO.
ECHO After a bit of thinking, you decide that a glass of milk will fix your thirst!
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO START5

:START5
cls
ECHO.
ECHO However, you realize that you've run out of milk and need to get a new carton...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO START6

:START6
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Check the refrigerator.
ECHO 2 - Get in your car.

ECHO. 
CHOICE /C 12 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE
IF %ERRORLEVEL% EQU 2 GOTO ENTERCAR

::THE FRIDGE PATH

:CHECKFRIDGE
cls
ECHO.
ECHO You decide to check your refrigerator.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE2

:CHECKFRIDGE2
cls
ECHO.
ECHO You open the refrigerator...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE3

:CHECKFRIDGE3
cls
ECHO.
ECHO ...And find a half-empty milk carton inside.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE4

:CHECKFRIDGE4
cls
ECHO.
ECHO (Maybe the sleeping pills you took last night made you forget about it?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE5

:CHECKFRIDGE5
cls
ECHO.
ECHO After staring at your fridge confused for a while, you pour yourself a glass of milk and take a sip... 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE6

:CHECKFRIDGE6
cls
ECHO.
ECHO ...It's spoiled. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE7

:CHECKFRIDGE7
cls
ECHO.
ECHO Overwhelmed by the foul taste of the milk, you pass out. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE8

:CHECKFRIDGE8
cls
ECHO.
ECHO (It might have been a good idea to smell the carton first...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO SPOILEDENDING

:SPOILEDENDING
cls
timeout /t 1 /nobreak >nul
cd "ASCII"
type GAMEOVER.txt
cd..
timeout /t 3 /nobreak >nul
ECHO.
ECHO You drank spoiled milk! What a way to ruin your afternoon!
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Start Over
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "What would you like to do"
IF %ERRORLEVEL% EQU 2 GOTO QUIT
IF %ERRORLEVEL% EQU 1 GOTO TITLE

::THE CAR PATH

:ENTERCAR
cls
ECHO.
ECHO You decide to get in your car.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO ENTERCAR2

:ENTERCAR2
cls
ECHO.
ECHO As a person living in the suburbs, you know that there's a variety of stores you can choose to go to.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO ENTERCAR3

:ENTERCAR3
cls
ECHO.
ECHO You don't go outside very often outside of work, and you don't really have a preferred place to shop for groceries.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO ENTERCAR4

:ENTERCAR4
cls
ECHO.
ECHO You find yourself in a bit of a pickle. What store should you go to?  
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO ENTERCAR5

:ENTERCAR5
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Go to Walmart.
ECHO 2 - Go to Costco.
ECHO 3 - Go to the nearest convenience store.
ECHO 4 - Turn around and return home.

ECHO. 
CHOICE /C 1234 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO WALMART
IF %ERRORLEVEL% EQU 2 GOTO COSTCO
IF %ERRORLEVEL% EQU 3 GOTO GASMART
IF %ERRORLEVEL% EQU 4 GOTO GOHOME

::THE WALMART PATH

:WALMART
cls
ECHO.
ECHO You decide to go to Walmart.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART2

:WALMART2
cls
ECHO.
ECHO You arrive and grab a shopping basket.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART3

:WALMART3
cls
ECHO.
ECHO Eventually, you find yourself at the Dairy section.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART4

:WALMART4
cls
ECHO.
ECHO ...All of the milk is out of stock.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART5

:WALMART5
cls
ECHO.
ECHO (What a bizarre anomaly...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART6

:WALMART6
cls
ECHO.
ECHO You decide that it's best to get back in your car and visit a different store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART16

:WALMART7
cls
ECHO.
ECHO You leave the store and get in your car.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART8

:WALMART8
cls
ECHO.
ECHO You turn the key...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART9

:WALMART9
cls
ECHO.
ECHO The car makes some noises and fails to start up.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART10

:WALMART10
cls
ECHO.
ECHO You try again...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART11

:WALMART11
cls
ECHO.
ECHO ...But to no avail.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART12

:WALMART12
cls
ECHO.
ECHO You sit in your car in frustration.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART13

:WALMART13
cls
ECHO.
ECHO After spending a bit of time thinking about life, you decide to get out of your car to inspect it.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART14

:WALMART14
cls
ECHO.
ECHO You open up the front hood...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART15

:WALMART15
cls
ECHO.
ECHO ...To find no motor inside.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART16

:WALMART16
cls
ECHO.
ECHO You leave the Walmart.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART17

:WALMART17
cls
ECHO.
ECHO ...Where's your car?
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART18

:WALMART18
cls
ECHO.
ECHO You soon figure out that your car had been stolen while you were in the store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO WALMART19

:WALMART19
cls
ECHO.
ECHO (What a bummer. How will you explain this to your boss tomorrow?) 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO STOLENEND

:STOLENEND
cls
timeout /t 1 /nobreak >nul
cd "ASCII"
type GAMEOVER.txt
cd..
timeout /t 3 /nobreak >nul
ECHO.
ECHO You've become a victim of car theft! There's no time to worry about milk anymore, how will you get home?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Start Over
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "What would you like to do"
IF %ERRORLEVEL% EQU 2 GOTO QUIT
IF %ERRORLEVEL% EQU 1 GOTO TITLE

::THE COSTCO PATH

:COSTCO
cls
ECHO.
ECHO You decide to go to Costco.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO COSTCO2

:COSTCO2
cls
ECHO.
ECHO Upon arriving, you are greeted by an employee who demands you for your membership card.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO COSTCO3

:COSTCO3
cls
ECHO.
ECHO ...You don't have one.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO COSTCO4

:COSTCO4
cls
ECHO.
ECHO The employee suggests for you to sign up for a fresh membership card.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO COSTCO5

:COSTCO5
cls
ECHO.
ECHO You find yourself indecisive.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO COSTCO6

:COSTCO5
cls
ECHO.
ECHO Should you leave and search for a different store or sign up for a membership card? (The latter takes some time!)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO COSTCO6

:COSTCO6
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Leave the store.
ECHO 2 - Sign up for a membership card.

ECHO. 
CHOICE /C 12 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO LEAVECOSTCO
IF %ERRORLEVEL% EQU 2 GOTO GETMEMBERSHIP


::THE LEAVE COSTCO PATH (LOOP)

:LEAVECOSTCO
cls
ECHO.
ECHO You decide to leave Costco.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEAVECOSTCO2

:LEAVECOSTCO2
cls
ECHO.
ECHO You get in your car and find yourself back on the road once again.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEAVECOSTCO3

:LEAVECOSTCO3
cls
ECHO.
ECHO Your desire for milk is still very great.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO ENTERCAR2

::THE GET MEMBERSHIP PATH

:GETMEMBERSHIP
cls
ECHO.
ECHO You decide to sign up for a membership card.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GETMEMBERSHIP2

:GETMEMBERSHIP2
cls
ECHO.
ECHO It took up about 10 minutes of your time, but you're finally granted permission into the store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GETMEMBERSHIP3

:GETMEMBERSHIP3
cls
ECHO.
ECHO You attempt to look for the dairy section for a bit, but you end up getting lost.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GETMEMBERSHIP4

:GETMEMBERSHIP4
cls
ECHO.
ECHO Should you continue searching or ask an employee for assistance?
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GETMEMBERSHIP5

:GETMEMBERSHIP5
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Continue searching.
ECHO 2 - Ask an employee for assistance.

ECHO. 
CHOICE /C 12 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH
IF %ERRORLEVEL% EQU 2 GOTO EMPLOYEE

::THE CONTINUE SEARCHING PATH

:CONTSEARCH
cls
ECHO.
ECHO You decide to continue your search alone.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH2

:CONTSEARCH2
cls
ECHO.
ECHO It took a while, but you end up finding the dairy section.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH3

:CONTSEARCH3
cls
ECHO.
ECHO To your relief, the freezers are fully stocked (and the milk is at a reasonable price)!
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH4

:CONTSEARCH4
cls
ECHO.
ECHO You grab a fresh carton and start heading back towards the registers.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH5

:CONTSEARCH5
cls
ECHO.
ECHO Unfortunately, you find yourself lost again.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH6

:CONTSEARCH6
cls
ECHO.
ECHO Should you go to the left or to the right?
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH7

:CONTSEARCH7
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Go left.
ECHO 2 - Go right.

ECHO. 
CHOICE /C 12 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO LEFT
IF %ERRORLEVEL% EQU 2 GOTO RIGHT

::THE LEFT PATH

:LEFT
cls
ECHO.
ECHO You decide to go to the left.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT2

:LEFT2
cls
ECHO.
ECHO You walk through a maze of shelves and displays.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT3

:LEFT3
cls
ECHO.
ECHO (It's somehow harder to get out...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT4

:LEFT4
cls
ECHO.
ECHO You find the registers after some time.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT5

:LEFT5
cls
ECHO.
ECHO You pay for the carton and leave the store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT6

:LEFT6
cls
ECHO.
ECHO As you head towards your car, you feel the desire for that first sip overwhelming you.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT7

:LEFT7
cls
ECHO.
ECHO You get in your car and drive home.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT8

:LEFT8
cls
ECHO.
ECHO Fueled with excitement and desire, you accidentally miss a turn and end up on an unusual intersection.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT9

:LEFT9
cls
ECHO.
ECHO You are unsure if you should continue driving forward or make a right turn.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO LEFT10

:LEFT10
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Keep driving forward.
ECHO 2 - Make a right turn.

ECHO. 
CHOICE /C 12 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO FORWARD
IF %ERRORLEVEL% EQU 2 GOTO TURNRIGHT

::THE FORWARD PATH

:FORWARD
cls
ECHO.
ECHO You decide to keep driving forward.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD2

:FORWARD2
cls
ECHO.
ECHO After a few minutes of driving, you notice a line of cars up ahead.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD3

:FORWARD3
cls
ECHO.
ECHO You attempt to turn around, but unfortunately for you, it's a one-lane road...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD4

:FORWARD4
cls
ECHO.
ECHO More cars line up behind you, leaving you with no escape from the road.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD5

:FORWARD5
cls
ECHO.
ECHO You decide to leave your car for a minute to determine what's going on.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD6

:FORWARD6
cls
ECHO.
ECHO A police officer stands on the side of the road and you ask him about the situation.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARDA

:FORWARDA
cls
ECHO.
ECHO ...A train derailed on the tracks not far from you and resulted in an unavoidable traffic jam. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD7

:FORWARD7
cls
ECHO.
ECHO Without much of a choice, you head back to your car.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD8

:FORWARD8
cls
ECHO.
ECHO You look down at your fresh carton of milk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD9

:FORWARD9
cls
ECHO.
ECHO You decide to open the carton as you wait for the traffic jam to clear.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO FORWARD10

:FORWARD10
cls
ECHO.
ECHO Amidst the cacophony of honking and chaos outside, you sit in your car, happily enjoying your milk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO JAMENDING

:JAMENDING
cls
timeout /t 1 /nobreak >nul
cd "ASCII"
type ALTCONGRATS.txt
cd..
timeout /t 3 /nobreak >nul
ECHO.
ECHO Although you're stuck in a traffic jam, at least you have your carton of milk to enjoy!
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Play Again
ECHO 2 - View Credits
ECHO 3 - Quit
ECHO.
CHOICE /C 123 /M "What would you like to do"
IF %ERRORLEVEL% EQU 3 GOTO QUIT
IF %ERRORLEVEL% EQU 2 GOTO CREDITS
IF %ERRORLEVEL% EQU 1 GOTO TITLE

::THE TURN RIGHT PATH

:TURNRIGHT
cls
ECHO.
ECHO You decide to make a right turn.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT2

:TURNRIGHT2
cls
ECHO.
ECHO You go through a bunch of strange turns and loops.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT3

:TURNRIGHT3
cls
ECHO.
ECHO Eventually, you end up on a familiar road.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT4

:TURNRIGHT4
cls
ECHO.
ECHO You breathe a sigh of relief as you continue making your way home.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT5

:TURNRIGHT5
cls
ECHO.
ECHO Eventually, you arrive back at your home.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT6

:TURNRIGHT6
cls
ECHO.
ECHO You enter your home and head straight for the kitchen.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT7

:TURNRIGHT7
cls
ECHO.
ECHO You grab a glass and pour yourself some milk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT8

:TURNRIGHT8
cls
ECHO.
ECHO A feeling of satisfaction and joy bestows upon you as you take your first sip.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT9


:TURNRIGHT9
cls
ECHO.
ECHO You return to enjoying your afternoon with your glass of milk. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNRIGHT10

:TURNRIGHT10
cls
ECHO.
ECHO Your thirst is quenched and you've completed your personal mission. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO BESTENDING

:BESTENDING
cls
timeout /t 1 /nobreak >nul
cd "ASCII"
type CONGRATS.txt
cd..
timeout /t 3 /nobreak >nul
ECHO.
ECHO You've successfuly acquired the milk and seized your afternoon! 
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Play Again
ECHO 2 - View Credits
ECHO 3 - Quit
ECHO.
CHOICE /C 123 /M "What would you like to do"
IF %ERRORLEVEL% EQU 3 GOTO QUIT
IF %ERRORLEVEL% EQU 2 GOTO CREDITS
IF %ERRORLEVEL% EQU 1 GOTO TITLE

::THE RIGHT PATH

:RIGHT
cls
ECHO.
ECHO You decide to go to the right.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT2

:RIGHT2
cls
ECHO.
ECHO You go through a bunch of narrow aisles.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT3

:RIGHT3
cls
ECHO.
ECHO (You feel more and more claustrophobic as you continue traversing...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT4

:RIGHT4
cls
ECHO.
ECHO Turning to your left, you trip...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT5

:RIGHT5
cls
ECHO.
ECHO ...And fall through the floor.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT6

:RIGHT6
cls
ECHO.
ECHO (Someone should've put a warning sign or something there...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT7

:RIGHT7
cls
ECHO.
ECHO You get knocked out from hitting the ground underneath the floor.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT8

:RIGHT8
cls
ECHO.
ECHO You wake up to find yourself surrounded by dated yellow wallpaper, wet carpeting, and drop ceilings covered in flourescent lighting.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT9

:RIGHT9
cls
ECHO.
ECHO You get up and start walking around.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT10

:RIGHT10
cls
ECHO.
ECHO The environment appears to go on forever in all directions. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT11

:RIGHT11
cls
ECHO.
ECHO Minutes go by as you're left confused as to where you are. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT12

:RIGHT12
cls
ECHO.
ECHO The sound of the buzzing flourescent lights slowly irritates you.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT13

:RIGHT13
cls
ECHO.
ECHO You suddenly hear something in the distance.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT14

:RIGHT14
cls
ECHO.
ECHO (Is it just your imagination?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT15

:RIGHT15
cls
ECHO.
ECHO You yell out "hello."
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT16

:RIGHT16
cls
ECHO.
ECHO You hear a distant growl in response to your cry.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT17

:RIGHT17
cls
ECHO.
ECHO Adrenaline settles in as you realize the kind of danger you're in.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT18

:RIGHT18
cls
ECHO.
ECHO (This isn't your imagination...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT19

:RIGHT19
cls
ECHO.
ECHO There's no time to worry about your milk anymore.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT20

:RIGHT20
cls
ECHO.
ECHO You start running for your life.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT21

:RIGHT21
cls
ECHO.
ECHO Fear washes over you as the sound gets closer and closer...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO BACKROOMSENDING

:BACKROOMSENDING
cls
timeout /t 1 /nobreak >nul
cd "ASCII"
type GAMEOVER.txt
cd..
timeout /t 3 /nobreak >nul
ECHO.
ECHO You're being chased by an unknown entity! You can't keep running forever...
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Start Over
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "What would you like to do"
IF %ERRORLEVEL% EQU 2 GOTO QUIT
IF %ERRORLEVEL% EQU 1 GOTO TITLE

::THE ASK EMPLOYEE PATH

:EMPLOYEE
cls
ECHO.
ECHO You decide to ask an employee.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE2

:EMPLOYEE2
cls
ECHO.
ECHO You go to the nearest employee and ask her where the dairy section is. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE3

:EMPLOYEE3
cls
ECHO.
ECHO She gives you a bunch of directions that you find confusing.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE4

:EMPLOYEE4
cls
ECHO.
ECHO (Turn left, then go straight, then turn right, then up a ladder, then go down some stairs?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE5

:EMPLOYEE5
cls
ECHO.
ECHO (What kind of store is this?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE6

:EMPLOYEE6
cls
ECHO.
ECHO You decide to disregard her directions and continue to look around alone.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE7

:EMPLOYEE7
cls
ECHO.
ECHO You go through many aisles, squeezing through tight shelves and walking past other shoppers. 
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE8

:EMPLOYEE8
cls
ECHO.
ECHO Eventually, you find a staircase going downwards.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE9

:EMPLOYEE9
cls
ECHO.
ECHO (Are these the stairs the employee mentioned earlier?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE10

:EMPLOYEE10
cls
ECHO.
ECHO You go down a single step, but you hesitate for a second.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE11

:EMPLOYEE11
cls
ECHO.
ECHO (Should you go down the stairs?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO EMPLOYEE12

:EMPLOYEE12
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Go down the stairs.
ECHO 2 - Turn around and continue searching.

ECHO. 
CHOICE /C 12 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS
IF %ERRORLEVEL% EQU 2 GOTO TURNAROUND


::THE DOWNSTAIRS PATH (JUMP)

:DOWNSTAIRS
cls
ECHO.
ECHO You decide to go down the stairs.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS2

:DOWNSTAIRS2
cls
ECHO.
ECHO A feeling of uneasiness creeps over you as you descend.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS3

:DOWNSTAIRS3
cls
ECHO.
ECHO Regardless, you make it down the stairs.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS4

:DOWNSTAIRS4
cls
ECHO.
ECHO A metal door faces your direction.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS5

:DOWNSTAIRS5
cls
ECHO.
ECHO You open the door.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS6

:DOWNSTAIRS6
cls
ECHO.
ECHO Walking inside, you are met with a very musty stench.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRSA

:DOWNSTAIRSA
cls
ECHO.
ECHO You are surrounded by dated yellow wallpaper, wet carpeting, and drop ceilings covered in flourescent lighting.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS7


:DOWNSTAIRS7
cls
ECHO.
ECHO (Is this really the dairy section?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS8

:DOWNSTAIRS8
cls
ECHO.
ECHO The feeling of uneasiness continues to hang on to you.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS9

:DOWNSTAIRS9
cls
ECHO.
ECHO (You feel as if you shouldn't be down here.)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS10

:DOWNSTAIRS10
cls
ECHO.
ECHO You start heading back to the door...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS11

:DOWNSTAIRS11
cls
ECHO.
ECHO ...Only to find that the door only opens in one way with no handle on your side.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS12

:DOWNSTAIRS12
cls
ECHO.
ECHO (Maybe the employee isn't good at their job...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS13

:DOWNSTAIRS13
cls
ECHO.
ECHO (This store really needs better management, maybe some bigger signs too...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO DOWNSTAIRS14

:DOWNSTAIRS14
cls
ECHO.
ECHO Now trapped in this strange place, you decide to start looking around.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO RIGHT10

::THE TURN AROUND PATH

:TURNAROUND
cls
ECHO.
ECHO You decide to turn around.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO TURNAROUND2

:TURNAROUND2
cls
ECHO.
ECHO Heading back up the stairs, you continue looking around the store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO CONTSEARCH2

::THE RETURN HOME PATH

:GOHOME
cls
ECHO.
ECHO You decide to go home.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GOHOME2

:GOHOME2
cls
ECHO.
ECHO (Maybe online shopping is better for you?)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GOHOME3

:GOHOME3
cls
ECHO.
ECHO You arrive home and leave your car.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GOHOME4

:GOHOME4
cls
ECHO.
ECHO Your desire for milk is still overwhelming.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GOHOME5

:GOHOME5
cls
ECHO.
ECHO What shall you do?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Check the refrigerator.
ECHO 2 - Go on Amazon.
ECHO 3 - Go back in your car.

ECHO. 
CHOICE /C 123 /M "Choose your answer."
IF %ERRORLEVEL% EQU 1 GOTO CHECKFRIDGE
IF %ERRORLEVEL% EQU 2 GOTO AMAZON
IF %ERRORLEVEL% EQU 3 GOTO RETURNCAR

::THE AMAZON PATH

:AMAZON
cls
ECHO.
ECHO You decide to go on Amazon.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON2

:AMAZON2
cls
ECHO.
ECHO Feeling cheap, you search for milk with the lowest prices.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON3

:AMAZON3
cls
ECHO.
ECHO You find the best option after a little bit of searching.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON4

:AMAZON4
cls
ECHO.
ECHO A carton for 99 cents? What more could you ask for!
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON6

:AMAZON5
cls
ECHO.
ECHO You purchase the carton.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON6

:AMAZON6
cls
ECHO.
ECHO You purchase the carton.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON7

:AMAZON7
cls
ECHO.
ECHO After about an hour, you receive the carton in the mail.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON8

:AMAZON8
cls
ECHO.
ECHO The package feels unusually light.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON9

:AMAZON9
cls
ECHO.
ECHO You feel anxious as you open up the package.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON10


:AMAZON10
cls
ECHO.
ECHO (You have a gut feeling that the carton is empty.)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON11

:AMAZON11
cls
ECHO.
ECHO After unraveling the package, you grab the carton and take a look inside.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON12

:AMAZON12
cls
ECHO.
ECHO ...Your gut was right.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO AMAZON13

:AMAZON13
cls
ECHO.
ECHO How idiotic of you! It was too good to be true...
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO SCAMENDING

:SCAMENDING
cls
timeout /t 1 /nobreak >nul
cd "ASCII"
type GAMEOVER.txt
cd..
timeout /t 3 /nobreak >nul
ECHO.
ECHO You got scammed! What can you possibly do with an empty carton?
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Start Over
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "What would you like to do"
IF %ERRORLEVEL% EQU 2 GOTO QUIT
IF %ERRORLEVEL% EQU 1 GOTO TITLE

::THE RETURN TO CAR PATH (LOOP)

:RETURNCAR
cls
ECHO.
ECHO You end up changing your mind and decide to get in your car again.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO ENTERCAR2

::THE CONVENIENCE STORE PATH

:GASMART
cls
ECHO.
ECHO You decide to go to the nearest convenience store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART2

:GASMART2
cls
ECHO.
ECHO It doesn't take you long to find one.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART3

:GASMART3
cls
ECHO.
ECHO You walk into the convenience store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART4

:GASMART4
cls
ECHO.
ECHO The place looks kind of sketchy, but you ignore the environment and head towards the freezer.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART5

:GASMART5
cls
ECHO.
ECHO The freezer appears to be stocked with generic-brand milk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART6

:GASMART6
cls
ECHO.
ECHO You grab a carton of milk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART7

:GASMART7
cls
ECHO.
ECHO You head to the counter and ring up the store clerk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART8

:GASMART8
cls
ECHO.
ECHO You pay the clerk and leave the store.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART9

:GASMART9
cls
ECHO.
ECHO Heading back to your car, you feel your desire for milk growing more than ever.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART10

:GASMART10
cls
ECHO.
ECHO You get in your car and drive home.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART11

:GASMART11
cls
ECHO.
ECHO Upon arriving home, you head straight to the kitchen.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART12

:GASMART12
cls
ECHO.
ECHO You grab a glass and pour yourself some milk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART13

:GASMART13
cls
ECHO.
ECHO A feeling of satisfaction and joy bestows upon you as you take your first sip.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART14

:GASMART14
cls
ECHO.
ECHO (The milk tastes kind of funny though...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART15

:GASMART15
cls
ECHO.
ECHO You return to enjoying your afternoon with your glass of milk.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART16

:GASMART16
cls
ECHO.
ECHO Thirty minutes pass and you feel your stomach grumbling.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART17

:GASMART17
cls
ECHO.
ECHO You have a sudden urge to use the bathroom.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART18

:GASMART18
cls
ECHO.
ECHO (Pain begins to boil in your gut...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART19

:GASMART19
cls
ECHO.
ECHO It appears that your milk was mixed with laxatives.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART20

:GASMART20
cls
ECHO.
ECHO (Perhaps the convenience store was a tad bit too sketchy...)
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART21

:GASMART21
cls
ECHO.
ECHO You sprint to the bathroom and lock yourself inside.
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO GASMART22

:GASMART22
cls
ECHO.
ECHO Congratulations! You've effectively messed up your whole afternoon!
timeout /t 2 /nobreak >nul
CHOICE /C 1 /M "-PRESS 1 TO CONTINUE-"
IF %ERRORLEVEL% EQU 1 GOTO POOPENDING

:POOPENDING
cls
timeout /t 1 /nobreak >nul
cd "ASCII"
type GAMEOVER.txt
cd..
timeout /t 3 /nobreak >nul
ECHO.
ECHO You got trolled! Maybe generic-brand milk isn't the right way to go... 
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Start Over
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "What would you like to do"
IF %ERRORLEVEL% EQU 2 GOTO QUIT
IF %ERRORLEVEL% EQU 1 GOTO TITLE

:CREDITS
ECHO.
ECHO -CREDITS-
ECHO.
ECHO Programmer, Testing, and Story - TheGamer2000
ECHO.
ECHO (C)2026 TG2000. All events that took place during this game are entirely fictitious.
ECHO Any real-life scenarios that are similar to the events depicted in the game are purely coincidential. 
ECHO.
timeout /t 2 /nobreak >nul
ECHO Options
ECHO 1 - Play Again
ECHO 2 - Quit
ECHO.
CHOICE /C 12 /M "What would you like to do"
IF %ERRORLEVEL% EQU 2 GOTO QUIT
IF %ERRORLEVEL% EQU 1 GOTO TITLE

:QUIT
cls
PAUSE

::END OF PROGRAM