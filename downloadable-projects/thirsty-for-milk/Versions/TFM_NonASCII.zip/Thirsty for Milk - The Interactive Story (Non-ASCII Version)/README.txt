Thirsty for Milk: The Interactive Story (Non-ASCII Version)

A Game By TheGamer2000, (C)2026

--------
RUN-DOWN
--------
You find yourself thirsty on a fine afternoon. Water doesn't cut it for you. 

You settle on a glass of milk, but you've run out of the stuff...

Help yourself get a milk carton before your thirst overwhelms you! 

----------------------
START GUIDE & CONTROLS
----------------------
Simply click on the ThirstyForMilk.bat file to begin playing!

(If on Windows CMD, type in ThirstyForMilk.bat while in this folder and hit the Enter key.)

Use the number keys to select an option when prompted.

If any errors are to occur at any time, use the CTRL+C command to quit the program.

-----
NOTES
-----
This version of "Thirsty for Milk" is only designed for use on machines running Windows Vista through 11.

Have fun playing!